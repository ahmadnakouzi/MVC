CREATE PROCEDURE GetRange()
  BEGIN
SELECT name, COUNT(fc.film_id) AS Number
FROM category AS cat, film_category fc, film f
WHERE cat.category_id = fc.category_id
AND fc.film_id = f.film_id
GROUP BY name
HAVING COUNT(fc.film_id) BETWEEN 55 AND  65;
END;

